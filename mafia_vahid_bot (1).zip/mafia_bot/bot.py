# فایل اصلی اجرای ربات

if __name__ == '__main__':
    print('Bot started')